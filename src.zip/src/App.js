
import './App.css';
import RegisterForm from './form';

function App() {
  return (
    <div className="App">
      <RegisterForm/>
    </div>
  );
}

export default App;
